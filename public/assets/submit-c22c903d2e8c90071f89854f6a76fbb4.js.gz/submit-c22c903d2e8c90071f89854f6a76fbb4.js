$(document).ready(function() {
  //Copy and pasting code
  setTimeout(function(){
    window.location = "/view/view?mapid="+id;
  }, 1000);

});
